import os
import json
import re
import threading
import time
import asyncio
import random
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, simpledialog, filedialog

import html2text # pyright: ignore[reportMissingImports]
import pyperclip # pyright: ignore[reportMissingModuleSource]

from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError, FloodWaitError
try:
    from telethon.errors.common import RpcError
except ImportError:
    try:
        from telethon.errors.rpcbase import RpcError
    except Exception:
        RpcError = Exception

# timezone support (Python 3.9+)
try:
    from zoneinfo import ZoneInfo
except Exception:
    try:
        from backports.zoneinfo import ZoneInfo
    except Exception:
        ZoneInfo = None

# Optional calendar widget
try:
    from tkcalendar import DateEntry
    TKCAL_AVAILABLE = True
except Exception:
    DateEntry = None
    TKCAL_AVAILABLE = False

# -------------------------
# Настройки (вставь свои ключи ниже или укажи в UI)
API_ID_DEFAULT = ""   # <- Вставь сюда API ID (число) от my.telegram.org
API_HASH_DEFAULT = "" # <- Вставь сюда API Hash (строка) от my.telegram.org
SESSION_NAME = "telegram_parser_session"  # файл сессии Telethon (будет создан)
DOWNLOADS_DIR = "downloads"
LOCAL_TZ = ZoneInfo("Europe/Amsterdam") if ZoneInfo else None
# -------------------------

# -------------------------
# Термины авиации
def build_full_aviation_terms():
    terms = [
        "f-22", "f-35", "f-16", "f-15", "истребитель", "бомбардировщик", "самолет", "вертолет",
        "ан-124", "ил-76", "су-27", "су-34", "су-25", "миг-29", "миг-31", "bayraktar", "tb2",
        "mq-9", "shahed", "с-400", "patriot", "buk", "pantsir", "дрон", "бпла", "авиабаза",
    ]
    ukrainian_terms = [
        "літак", "безпілотник", "політ", "посадка", "зліт"
    ]
    all_terms = terms + ukrainian_terms
    s = set()
    for term in all_terms:
        t = term.strip()
        if not t:
            continue
        s.add(t)
        s.add(t.lower())
        s.add(t.upper())
        s.add(t.capitalize())
        s.add(t.replace('-', ' '))
        s.add(t.replace(' ', '-'))
        if '-' in t:
            s.add(t.replace('-', ''))
    return s

AVIATION_TERMS = build_full_aviation_terms()

# -------------------------
# Helpers

def normalize_channel_input(url_or_username: str) -> str:
    u = (url_or_username or "").strip()
    if not u:
        return ""
    if u.startswith("https://t.me/") or u.startswith("http://t.me/"):
        parts = u.rstrip('/').split('/')
        for p in reversed(parts):
            if p and p not in ('s', 'c'):
                return p
        return parts[-1]
    if u.startswith('@'):
        return u[1:]
    return u


def parse_input_date_to_local(dt_str: str):
    s = (dt_str or "").strip()
    if not s:
        return None
    # accept several formats: YYYY-MM-DD[ HH:MM:SS], DD.MM.YYYY, DD.MM.YYYY HH:MM:SS
    fmts = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d.%m.%Y %H:%M:%S", "%d.%m.%Y"]
    for f in fmts:
        try:
            naive = datetime.strptime(s, f)
            if LOCAL_TZ:
                aware = naive.replace(tzinfo=LOCAL_TZ)
            else:
                aware = naive
            return aware
        except Exception:
            continue
    return None


def msgdate_to_local_aware(msg_date):
    if msg_date is None:
        return None
    if hasattr(msg_date, 'tzinfo') and msg_date.tzinfo is None:
        # Telethon usually returns aware (UTC). If naive, assume UTC
        try:
            msg_date = msg_date.replace(tzinfo=ZoneInfo("UTC"))
        except Exception:
            pass
    try:
        if LOCAL_TZ:
            return msg_date.astimezone(LOCAL_TZ)
        return msg_date
    except Exception:
        return msg_date


def contains_aviation_terms(text: str):
    if not text:
        return False
    low = text.lower()
    for term in AVIATION_TERMS:
        if term.lower() in low:
            return True
    patterns = [
        r'\b[а-яa-z]{0,3}-?\d+\b',  # e.g. su-27, f16, mig-29
    ]
    for p in patterns:
        if re.search(p, low, re.IGNORECASE):
            return True
    return False

# Utility: run an async coroutine in a new event loop (in same thread)
def run_coro_in_new_loop(coro):
    loop = asyncio.new_event_loop()
    try:
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(coro)
    finally:
        try:
            loop.run_until_complete(loop.shutdown_asyncgens())
        except Exception:
            pass
        loop.close()
        try:
            asyncio.set_event_loop(None)
        except Exception:
            pass

# -------------------------
# GUI + Telethon handling
class TelegramParserGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Парсер Telegram — Авиация (Telethon) — v2")
        self.root.geometry("1120x880")

        # state
        self.parsed_data = []
        self.parsing_thread = None
        self.stop_flag = False

        # UI vars
        self.api_id_var = tk.StringVar(value=str(API_ID_DEFAULT) if API_ID_DEFAULT else "")
        self.api_hash_var = tk.StringVar(value=API_HASH_DEFAULT if API_HASH_DEFAULT else "")
        self.phone_var = tk.StringVar(value="")
        self.url_var = tk.StringVar(value="")
        self.use_date_filter = tk.BooleanVar(value=False)
        self.start_date_var = tk.StringVar(value="")
        self.end_date_var = tk.StringVar(value="")
        self.include_media_var = tk.BooleanVar(value=True)
        self.limit_messages_var = tk.BooleanVar(value=False)
        self.limit_count_var = tk.StringVar(value="100")
        self.reverse_var = tk.BooleanVar(value=True)
        # new
        self.safe_mode_var = tk.BooleanVar(value=True)
        self.delay_min_var = tk.StringVar(value="0.30")
        self.delay_max_var = tk.StringVar(value="0.60")

        # references to entry widgets (to enable/disable reliably)
        self.start_entry = None
        self.end_entry = None

        self.setup_ui()

    def setup_ui(self):
        frame = ttk.Frame(self.root, padding=10)
        frame.grid(row=0, column=0, sticky="nsew")
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        # API / Auth frame
        api_frame = ttk.LabelFrame(frame, text="Настройки Telegram API / Авторизация", padding=6)
        api_frame.grid(row=0, column=0, sticky="ew")
        api_frame.columnconfigure(5, weight=1)
        ttk.Label(api_frame, text="api_id:").grid(row=0, column=0, sticky="w")
        e_api_id = ttk.Entry(api_frame, textvariable=self.api_id_var, width=12)
        e_api_id.grid(row=0, column=1, sticky="w", padx=4)
        ttk.Button(api_frame, text="📋", width=3, command=lambda v=self.api_id_var: self.paste_to_var(v)).grid(row=0, column=2, padx=2)
        ttk.Label(api_frame, text="api_hash:").grid(row=0, column=3, sticky="w")
        e_api_hash = ttk.Entry(api_frame, textvariable=self.api_hash_var)
        e_api_hash.grid(row=0, column=4, sticky="ew", padx=4)
        ttk.Button(api_frame, text="📋", width=3, command=lambda v=self.api_hash_var: self.paste_to_var(v)).grid(row=0, column=5, padx=2)
        ttk.Label(api_frame, text="Телефон (необязательно, для авторизации):").grid(row=1, column=0, sticky="w", pady=4)
        e_phone = ttk.Entry(api_frame, textvariable=self.phone_var, width=20)
        e_phone.grid(row=1, column=1, sticky="w")
        ttk.Button(api_frame, text="📋", width=3, command=lambda v=self.phone_var: self.paste_to_var(v)).grid(row=1, column=2, padx=2)
        ttk.Button(api_frame, text="Подключиться / Авторизоваться", command=self.auth_telethon).grid(row=1, column=5, sticky="e", padx=4)

        # Channel input
        ch_frame = ttk.LabelFrame(frame, text="Канал (ссылка или имя пользователя)", padding=6)
        ch_frame.grid(row=1, column=0, sticky="ew", pady=6)
        ttk.Label(ch_frame, text="Канал (например https://t.me/WarPeaceAndYou):").grid(row=0, column=0, sticky="w")
        ch_frame.columnconfigure(0, weight=1)
        e_channel = ttk.Entry(ch_frame, textvariable=self.url_var)
        e_channel.grid(row=1, column=0, sticky="ew", padx=2, pady=2)
        ttk.Button(ch_frame, text="Вставить из буфера", command=lambda v=self.url_var: self.paste_to_var(v)).grid(row=1, column=1, padx=4)

        # Date filter
        date_frame = ttk.LabelFrame(frame, text="Фильтр по дате (локальная зона: Europe/Amsterdam)", padding=6)
        date_frame.grid(row=2, column=0, sticky="ew", pady=6)
        ttk.Checkbutton(date_frame, text="Использовать фильтр по дате", variable=self.use_date_filter, command=self.toggle_date_filter).grid(row=0, column=0, sticky="w")
        ttk.Label(date_frame, text="С (YYYY-MM-DD  или  YYYY-MM-DD HH:MM:SS  или  DD.MM.YYYY):").grid(row=1, column=0, sticky="w", pady=4)

        # Start date: if tkcalendar available use DateEntry
        if TKCAL_AVAILABLE:
            self.start_entry = DateEntry(date_frame, textvariable=self.start_date_var, date_pattern='yyyy-mm-dd')
        else:
            self.start_entry = ttk.Entry(date_frame, textvariable=self.start_date_var)
        self.start_entry.grid(row=1, column=1, sticky="ew")
        ttk.Button(date_frame, text="📋", width=3, command=lambda v=self.start_date_var: self.paste_to_var(v)).grid(row=1, column=2, padx=2)
        ttk.Button(date_frame, text="Сегодня", command=lambda v=self.start_date_var: v.set(datetime.now().strftime('%Y-%m-%d'))).grid(row=1, column=3, padx=6)

        ttk.Label(date_frame, text="По:").grid(row=1, column=4, sticky="w", padx=6)
        if TKCAL_AVAILABLE:
            self.end_entry = DateEntry(date_frame, textvariable=self.end_date_var, date_pattern='yyyy-mm-dd')
        else:
            self.end_entry = ttk.Entry(date_frame, textvariable=self.end_date_var)
        self.end_entry.grid(row=1, column=5, sticky="ew")
        ttk.Button(date_frame, text="📋", width=3, command=lambda v=self.end_date_var: self.paste_to_var(v)).grid(row=1, column=6, padx=2)
        ttk.Button(date_frame, text="Сегодня", command=lambda v=self.end_date_var: v.set(datetime.now().strftime('%Y-%m-%d'))).grid(row=1, column=7, padx=6)

        date_frame.columnconfigure(1, weight=1)
        date_frame.columnconfigure(5, weight=1)
        ttk.Label(date_frame, text="Формат: ГГГГ-ММ-ДД  или  ГГГГ-ММ-ДД ЧЧ:ММ:СС  или  ДД.MM.ГГГГ", foreground="gray").grid(row=2, column=0, columnspan=8, sticky="w")

        # Options
        opts_frame = ttk.LabelFrame(frame, text="Опции", padding=6)
        opts_frame.grid(row=3, column=0, sticky="ew", pady=6)
        ttk.Checkbutton(opts_frame, text="Скачивать медиа (фото/видео)", variable=self.include_media_var).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(opts_frame, text="Ограничить количество совпадений", variable=self.limit_messages_var).grid(row=0, column=1, sticky="w")
        e_limit = ttk.Entry(opts_frame, textvariable=self.limit_count_var, width=8)
        e_limit.grid(row=0, column=2, sticky="w", padx=6)
        ttk.Button(opts_frame, text="📋", width=3, command=lambda v=self.limit_count_var: self.paste_to_var(v)).grid(row=0, column=3, padx=2)
        ttk.Checkbutton(opts_frame, text="Сортировать старые -> новые", variable=self.reverse_var).grid(row=0, column=4, sticky="w")

        # Safe mode + delays
        ttk.Checkbutton(opts_frame, text="Безопасный режим (рекомендуется)", variable=self.safe_mode_var).grid(row=1, column=0, sticky="w", pady=6)
        ttk.Label(opts_frame, text="Задержка min (сек):").grid(row=1, column=1, sticky="w")
        ttk.Entry(opts_frame, textvariable=self.delay_min_var, width=8).grid(row=1, column=2, sticky="w", padx=4)
        ttk.Label(opts_frame, text="Задержка max (сек):").grid(row=1, column=3, sticky="w")
        ttk.Entry(opts_frame, textvariable=self.delay_max_var, width=8).grid(row=1, column=4, sticky="w", padx=4)

        # Buttons
        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=4, column=0, sticky="ew", pady=6)
        ttk.Button(btn_frame, text="Подключиться / Авторизоваться", command=self.auth_telethon).pack(side="left", padx=4)
        self.start_btn = ttk.Button(btn_frame, text="Начать парсинг", command=self.start_parsing)
        self.start_btn.pack(side="left", padx=4)
        self.stop_btn = ttk.Button(btn_frame, text="Остановить", command=self.stop_parsing, state="disabled")
        self.stop_btn.pack(side="left", padx=4)
        self.export_btn = ttk.Button(btn_frame, text="Экспорт JSON (Сохранить как...)", command=self.export_json, state="disabled")
        self.export_btn.pack(side="left", padx=4)
        ttk.Button(btn_frame, text="Очистить", command=self.clear_output).pack(side="left", padx=4)

        # Progress/Status
        self.progress = ttk.Progressbar(frame, mode="determinate")
        self.progress.grid(row=5, column=0, sticky="ew", pady=6)
        status_frame = ttk.Frame(frame)
        status_frame.grid(row=6, column=0, sticky="ew")
        self.status_var = tk.StringVar(value="Готово")
        ttk.Label(status_frame, textvariable=self.status_var).pack(side="left")
        self.count_var = tk.StringVar(value="Найдено: 0")
        ttk.Label(status_frame, textvariable=self.count_var).pack(side="right")

        # Output area
        out_frame = ttk.LabelFrame(frame, text="Результаты (найденные сообщения)", padding=6)
        out_frame.grid(row=7, column=0, sticky="nsew", pady=6)
        frame.rowconfigure(7, weight=1)
        out_frame.rowconfigure(0, weight=1)
        out_frame.columnconfigure(0, weight=1)
        self.output_text = scrolledtext.ScrolledText(out_frame, wrap="word", font=("Consolas", 10))
        self.output_text.grid(row=0, column=0, sticky="nsew")

        # Bindings
        self.root.bind_all("<Control-v>", self.global_ctrl_v)
        self.root.bind_all("<Control-V>", self.global_ctrl_v)

        # Initially disable date entries
        self.toggle_date_filter()

    # Paste helpers
    def paste_to_var(self, var: tk.StringVar):
        try:
            txt = pyperclip.paste()
            if txt is not None:
                var.set(txt)
        except Exception as e:
            messagebox.showerror("Ошибка буфера", str(e))

    def global_ctrl_v(self, event=None):
        try:
            widget = self.root.focus_get()
            txt = pyperclip.paste()
            if not txt:
                return "break"
            if isinstance(widget, tk.Entry) or isinstance(widget, ttk.Entry):
                widget.delete(0, tk.END)
                widget.insert(0, txt)
                return "break"
            if isinstance(widget, tk.Text) or isinstance(widget, tk.scrolledtext.ScrolledText):
                widget.insert(tk.INSERT, txt)
                return "break"
        except Exception:
            pass
        return None

    def toggle_date_filter(self):
        state = "normal" if self.use_date_filter.get() else "disabled"
        try:
            if isinstance(self.start_entry, ttk.Entry) or isinstance(self.start_entry, tk.Entry):
                self.start_entry.config(state=state)
            else:
                # DateEntry has configure too
                self.start_entry.config(state=state)
        except Exception:
            pass
        try:
            if isinstance(self.end_entry, ttk.Entry) or isinstance(self.end_entry, tk.Entry):
                self.end_entry.config(state=state)
            else:
                self.end_entry.config(state=state)
        except Exception:
            pass

    def set_status(self, s):
        self.status_var.set(s)
        self.root.update_idletasks()

    # Async auth flow executed in a new event loop inside a background thread
    def auth_telethon(self):
        try:
            api_id_val = self.api_id_var.get().strip()
            api_hash_val = self.api_hash_var.get().strip()
            api_id = int(api_id_val) if api_id_val else None
            api_hash = api_hash_val if api_hash_val else None
        except Exception:
            messagebox.showerror("API", "api_id должен быть числом, api_hash — строка.")
            return

        if not api_id or not api_hash:
            messagebox.showinfo("Инструкция", "Введите API ID и API Hash (получены на my.telegram.org).")
            return

        phone = self.phone_var.get().strip() or None
        self.set_status("Подключение к Telegram...")

        def _thread_auth():
            async def auth_coro():
                client = TelegramClient(SESSION_NAME, api_id, api_hash)
                try:
                    await client.connect()
                    if not await client.is_user_authorized():
                        ph = phone
                        if not ph:
                            ph = self.ask_main_thread("Телефон", "Введите телефон в международном формате (например +71234567890):")
                            if not ph:
                                self.set_status("Авторизация отменена")
                                await client.disconnect()
                                return False
                        try:
                            await client.send_code_request(ph)
                        except Exception as exc:
                            await client.disconnect()
                            self.set_status("Не удалось отправить код")
                            self.call_showerror_main_thread("Ошибка авторизации", f"Не удалось отправить код: {exc}")
                            return False
                        code = self.ask_main_thread("Код", "Введите код из Telegram:")
                        if not code:
                            await client.disconnect()
                            self.set_status("Авторизация отменена")
                            return False
                        try:
                            await client.sign_in(ph, code)
                        except SessionPasswordNeededError:
                            password = self.ask_main_thread("2FA", "Введите пароль двухэтапной проверки:", password=True)
                            if not password:
                                await client.disconnect()
                                self.set_status("Авторизация отменена")
                                return False
                            try:
                                await client.sign_in(password=password)
                            except Exception as exc:
                                await client.disconnect()
                                self.call_showerror_main_thread("Ошибка 2FA", f"Двухэтапная проверка не прошла: {exc}")
                                self.set_status("Авторизация не удалась")
                                return False
                        except Exception as exc:
                            await client.disconnect()
                            self.call_showerror_main_thread("Ошибка входа", f"Вход не удался: {exc}")
                            self.set_status("Авторизация не удалась")
                            return False
                    await client.disconnect()
                    self.set_status("Авторизация завершена")
                    self.call_showinfo_main_thread("Авторизация", "Успешно. Сессия сохранена.")
                    return True
                except Exception as exc:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                    self.set_status("Не удалось подключиться")
                    self.call_showerror_main_thread("Ошибка соединения", str(exc))
                    return False

            try:
                run_coro_in_new_loop(auth_coro())
            except Exception as e:
                self.call_showerror_main_thread("Ошибка авторизации", str(e))
                self.set_status("Ошибка авторизации")

        threading.Thread(target=_thread_auth, daemon=True).start()

    # helper to ask user from background thread via main loop and get result
    def ask_main_thread(self, title, prompt, password=False):
        result_container = {"value": None}
        def ask():
            if password:
                res = simpledialog.askstring(title, prompt, parent=self.root, show="*")
            else:
                res = simpledialog.askstring(title, prompt, parent=self.root)
            result_container["value"] = res
        self.root.after(0, ask)
        while result_container["value"] is None:
            time.sleep(0.05)
        return result_container["value"]

    def call_showerror_main_thread(self, title, text):
        self.root.after(0, lambda: messagebox.showerror(title, text))

    def call_showinfo_main_thread(self, title, text):
        self.root.after(0, lambda: messagebox.showinfo(title, text))

    # Parsing (each parsing run creates its own event loop inside background thread)
    def start_parsing(self):
        try:
            api_id_val = self.api_id_var.get().strip()
            api_hash_val = self.api_hash_var.get().strip()
            api_id = int(api_id_val) if api_id_val else None
            api_hash = api_hash_val if api_hash_val else None
        except Exception:
            messagebox.showerror("API", "Неверные api_id/api_hash")
            return

        url_input = self.url_var.get().strip()
        if not url_input:
            messagebox.showerror("Ввод", "Введите ссылку или имя канала")
            return
        channel = normalize_channel_input(url_input)
        if not channel:
            messagebox.showerror("Ввод", "Не удалось распознать канал. Проверьте ввод.")
            return

        # date filters
        start_dt = None
        end_dt = None
        if self.use_date_filter.get():
            sd = self.start_date_var.get().strip()
            ed = self.end_date_var.get().strip()
            if sd:
                start_dt = parse_input_date_to_local(sd)
                if not start_dt:
                    messagebox.showerror("Дата", "Неверная начальная дата. Формат: YYYY-MM-DD или YYYY-MM-DD HH:MM:SS или DD.MM.YYYY")
                    return
            if ed:
                end_dt = parse_input_date_to_local(ed)
                if not end_dt:
                    messagebox.showerror("Дата", "Неверная конечная дата. Формат: YYYY-MM-DD или YYYY-MM-DD HH:MM:SS или DD.MM.YYYY")
                    return
                # if user gave only date (no time), extend to end of day
                if ' ' not in ed and '.' not in ed:
                    end_dt = end_dt + timedelta(days=1) - timedelta(seconds=1)

        include_media = self.include_media_var.get()
        limit_matches = None
        if self.limit_messages_var.get():
            try:
                limit_matches = int(self.limit_count_var.get())
            except Exception:
                limit_matches = None

        # delays
        try:
            dmin = float(self.delay_min_var.get())
            dmax = float(self.delay_max_var.get())
            if dmin < 0: dmin = 0.0
            if dmax < dmin: dmax = dmin
        except Exception:
            dmin, dmax = 0.3, 0.6

        # clear UI
        self.parsed_data = []
        self.output_text.delete("1.0", tk.END)
        self.progress['value'] = 0
        self.count_var.set("Найдено: 0")
        self.set_status(f"Начинаю парсинг {channel} ...")

        self.stop_flag = False
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.export_btn.config(state="disabled")

        def _thread_parse():
            async def parse_coro():
                client = TelegramClient(SESSION_NAME, api_id, api_hash)
                found = []
                flood_retries = 0
                max_flood_retries = 5
                try:
                    await client.connect()
                except Exception as exc:
                    self.call_showerror_main_thread("Ошибка клиента", f"Не удалось подключиться: {exc}")
                    self.root.after(0, self.parsing_done)
                    return

                try:
                    ch_dir = os.path.join(DOWNLOADS_DIR, channel)
                    if include_media and not os.path.exists(ch_dir):
                        os.makedirs(ch_dir, exist_ok=True)

                    async for msg in client.iter_messages(channel, limit=None):
                        if self.stop_flag:
                            break

                        # safe delay between iterations if safe_mode enabled
                        if self.safe_mode_var.get():
                            await asyncio.sleep(random.uniform(dmin, dmax))

                        msg_date = getattr(msg, 'date', None)
                        msg_date_local = msgdate_to_local_aware(msg_date) if msg_date else None

                        # date filters
                        if (start_dt or end_dt):
                            if not msg_date_local:
                                continue
                            if start_dt and msg_date_local < start_dt:
                                continue
                            if end_dt and msg_date_local > end_dt:
                                continue

                        text = (msg.message or "")
                        if contains_aviation_terms(text):
                            entry = {
                                "id": getattr(msg, 'id', None),
                                "url": f"https://t.me/{channel}/{getattr(msg, 'id', '')}",
                                "text": text,
                                "datetime": msg_date_local.isoformat() if msg_date_local else "",
                                "aviation_terms": [],
                                "photos": [],
                                "videos": [],
                                "files": [],
                                "markdown": ""
                            }
                            t_low = text.lower()
                            matched = []
                            for term in AVIATION_TERMS:
                                if term.lower() in t_low:
                                    matched.append(term)
                            entry["aviation_terms"] = matched

                            if include_media and getattr(msg, 'media', None):
                                try:
                                    # extra delay before download
                                    if self.safe_mode_var.get():
                                        await asyncio.sleep(random.uniform(dmin, dmax))
                                    saved = await client.download_media(msg, file=ch_dir)
                                    if saved:
                                        if isinstance(saved, list):
                                            for s in saved:
                                                if isinstance(s, str):
                                                    if s.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')):
                                                        entry['photos'].append(s)
                                                    elif s.lower().endswith(('.mp4', '.mov', '.mkv', '.webm', '.avi', '.ogg')):
                                                        entry['videos'].append(s)
                                                    else:
                                                        entry['files'].append(s)
                                        else:
                                            s = saved
                                            if s.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')):
                                                entry['photos'].append(s)
                                            elif s.lower().endswith(('.mp4', '.mov', '.mkv', '.webm', '.avi', '.ogg')):
                                                entry['videos'].append(s)
                                            else:
                                                entry['files'].append(s)
                                except FloodWaitError as f:
                                    # exponential backoff and continue
                                    flood_retries += 1
                                    wait = min(f.seconds + 1 + 2**flood_retries, 600)
                                    self.set_status(f"FloodWait: sleeping {wait}s (retry {flood_retries})")
                                    await asyncio.sleep(wait)
                                    if flood_retries > max_flood_retries:
                                        self.call_showerror_main_thread("FloodWait", "Слишком много ожиданий FloodWait — прерываю")
                                        break
                                except Exception as e:
                                    print("Ошибка скачивания медиа:", e)

                            try:
                                entry['markdown'] = html2text.html2text(entry['text'])
                            except Exception:
                                entry['markdown'] = entry['text']

                            found.append(entry)
                            self.parsed_data = found
                            self.root.after(0, self.update_ui_partial, entry, len(found))

                            if limit_matches and len(found) >= limit_matches:
                                break

                        # short polite sleep when not matching (extra low)
                        if not self.safe_mode_var.get():
                            await asyncio.sleep(0)

                    # finished iter
                    if self.reverse_var.get() and self.parsed_data:
                        self.parsed_data = list(reversed(self.parsed_data))

                except RpcError as e:
                    self.call_showerror_main_thread("Ошибка Telethon RPC", str(e))
                except Exception as e:
                    self.call_showerror_main_thread("Ошибка парсинга", str(e))
                finally:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                    self.root.after(0, self.parsing_done)

            try:
                run_coro_in_new_loop(parse_coro())
            except Exception as e:
                self.call_showerror_main_thread("Ошибка парсинга", str(e))
                self.root.after(0, self.parsing_done)

        self.parsing_thread = threading.Thread(target=_thread_parse, daemon=True)
        self.parsing_thread.start()

    def update_ui_partial(self, entry, index):
        lines = []
        lines.append(f"--- Сообщение {index} ---")
        lines.append(f"Дата: {entry.get('datetime','')}")
        snippet = entry.get('text','')
        if len(snippet) > 1500:
            snippet = snippet[:1500] + " ... (усечено)"
        lines.append(f"Текст: {snippet}")
        if entry.get('aviation_terms'):
            lines.append("Термины: " + ", ".join(entry['aviation_terms'][:10]))
        if entry.get('photos'):
            lines.append(f"Фото: {len(entry['photos'])}")
        if entry.get('videos'):
            lines.append(f"Видео: {len(entry['videos'])}")
        lines.append(f"Ссылка: {entry.get('url')}")
        lines.append("")
        self.output_text.insert(tk.END, "\n".join(lines))
        self.output_text.see(tk.END)
        self.count_var.set(f"Найдено: {len(self.parsed_data)}")

    def parsing_done(self):
        self.set_status("Парсинг завершён")
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.export_btn.config(state="normal")
        self.progress['value'] = 100
        self.count_var.set(f"Найдено: {len(self.parsed_data)}")

    def stop_parsing(self):
        self.stop_flag = True
        self.set_status("Останавливаю...")
        self.stop_btn.config(state="disabled")

    def export_json(self):
        if not self.parsed_data:
            messagebox.showwarning("Экспорт", "Нет данных для экспорта")
            return
        # Ask user where to save
        safe_channel_name = re.sub(r'[^0-9A-Za-z_\-]', '_', normalize_channel_input(self.url_var.get() or 'export'))
        default_name = f"telegram_aviation_export_{safe_channel_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        fn = filedialog.asksaveasfilename(defaultextension='.json', initialfile=default_name, filetypes=[('JSON files','*.json'),('All files','*.*')])
        if not fn:
            return
        try:
            with open(fn, "w", encoding="utf-8") as f:
                json.dump(self.parsed_data, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("Экспорт", f"Экспортировано в {fn}")
        except Exception as e:
            messagebox.showerror("Ошибка экспорта", str(e))

    def clear_output(self):
        self.output_text.delete("1.0", tk.END)
        self.parsed_data = []
        self.progress['value'] = 0
        self.count_var.set("Найдено: 0")
        self.set_status("Готово")

# Run
def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use('clam')
    except Exception:
        pass
    app = TelegramParserGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
