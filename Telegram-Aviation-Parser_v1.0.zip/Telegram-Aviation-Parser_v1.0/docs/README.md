# Telegram-Aviation-Parser
Telegram Aviation Parser — Python-программа для парсинга публичных Telegram-каналов, поиска упоминаний авиационной техники, извлечения текста/медиа и экспорта результатов в JSON. Автор: Matpac445.
